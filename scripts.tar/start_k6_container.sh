nerdctl run --name k6 --rm  --entrypoint "sleep" stratum.owmobility.com/stratumcnf/enea-k6:latest infinity &
