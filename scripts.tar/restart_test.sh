date;
kubectl rollout restart $@
kubectl rollout status $@
date
