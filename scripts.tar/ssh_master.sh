ssh  azureuser@107.243.72.22 $@
